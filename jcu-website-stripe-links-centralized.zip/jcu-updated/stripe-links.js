// Stripe Payment Links Configuration
// ------------------------------------------------------------
// Paste your Stripe Payment Links below.
// You only need to edit this file when a Stripe link changes.
//
// Example:
// premium: "https://buy.stripe.com/abc123",
// ------------------------------------------------------------

const STRIPE_LINKS = {
  premium: "PASTE_PREMIUM_STRIPE_LINK_HERE",
  professional: "PASTE_PROFESSIONAL_STRIPE_LINK_HERE",
  enterprise: "PASTE_ENTERPRISE_STRIPE_LINK_HERE",
  elite: "PASTE_ELITE_STRIPE_LINK_HERE"
};

function getStripeLink(planName) {
  const link = STRIPE_LINKS[planName];

  if (!link || link.includes("PASTE_") || link === "#") {
    alert("Stripe link for " + planName + " is not added yet. Please update stripe-links.js.");
    return "#";
  }

  return link;
}
